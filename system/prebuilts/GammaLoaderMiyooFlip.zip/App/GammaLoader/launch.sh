#!/bin/sh

IMAGE_PATH="/mnt/SDCARD/App/GammaLoader/installing.png"
/usr/bin/fbdisplay "$IMAGE_PATH" & 

echo heartbeat > /sys/class/leds/charger/trigger
echo mmc2 > /sys/class/leds/work/trigger

dd if=GammaLoader.img of=/dev/mtdblock2

echo none > /sys/class/leds/work/trigger
echo none > /sys/class/leds/charger/trigger

echo b > /proc/sysrq-trigger